# Dictionary-Application
This is a Dictionary Android Application in which you can search a word and get its meaning. Used Dictionary API and Volley Library to establish a connection between my application and internet. Designed in Android Studio using Kotlin .
![Dict S1](https://user-images.githubusercontent.com/65021212/126311064-44b0d803-9048-4802-8095-61b9912e0f4e.jpg)
![Dict S2](https://github.com/jadonmj/Dictionary-Application/blob/main/Dict%20S2.jpg)
